import logging
import requests
import json
import time


logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info('Python HTTP trigger function processed a request.')
    book_id= event['book_id']
    #print(book_id)
    auth_token='dapi1ac9a8b25cb9bb7c400f3f555f5c2cc7' 
    hed = {'Authorization': 'Bearer ' + auth_token}
    sql_query = "select * from books where id= " + json.dumps(event['book_id']) #"select count(*) from 02_tpch_delta"#
    #print(sql_query)
    data = {"language": "sql", "clusterId": "1215-181437-chase192", "contextId": "1325636980364012002", "command": sql_query}
    url = 'https://demo.cloud.databricks.com/api/1.2/commands/execute'
    response = requests.post(url, json=data, headers=hed) #submitt command via POST API
    responsejson = response.json() # capture the response of command submit API
    logger.info('command submitted to Databricks')
    if response.status_code==200:  # command submission successful
        #responsejson = response.json() # capture the response of command submit API
        get_url='https://demo.cloud.databricks.com/api/1.2/commands/status?clusterId=1215-181437-chase192&contextId=1325636980364012002&commandId='+responsejson["id"]
        res_output= requests.get(get_url, headers=hed) # get API to check the status of the command submitted
        res_output_json = res_output.json() 
        status= res_output_json["status"] #update the status variable with the latest status
        
        if status=="Running": # continue to check the status of the command till the command is in the "Running" status
            while status=="Running":
                res_output= requests.get(get_url, headers=hed) # get API to check the status of the command
                res_output_json = res_output.json() 
                status= res_output_json["status"] #update the status variable with the latest status
                time.sleep(2) # add delay in the get API to aviod flood of API request    
        
        # status is in "Queued" state
        if status=="Queued":
             while status=="Queued": # continue to check the status of the command till the command is in the "Queued" status
                res_output= requests.get(get_url, headers=hed) # get API to check the status of the command
                res_output_json = res_output.json() 
                status= res_output_json["status"] #update the status variable with the latest status
                time.sleep(2) # add delay in the get API to aviod flood of API request

         #command execution is Finished
        if  status=="Finished": # once the command is completed, check the type of result
            if res_output_json["results"]["resultType"]== "table": #command was successful and result came back in the table form, return the output
                fresults=res_output_json["results"]["data"]
                #print(fresults)
                return fresults #func.HttpResponse(f"{fresults}") #return the results back
            elif res_output_json["results"]["resultType"]== "error":  # command was unsuccessful and return error message
                ferror=res_output_json["results"]["summary"]   
                return ferror #func.HttpResponse(f"{ferror}")
    
    elif response.status_code==500:  #serevr side error
         server_error = responsejson["error"]
         return server_error #func.HttpResponse(f"{server_error}")    #return the error message
    